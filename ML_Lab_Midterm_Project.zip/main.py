from pathlib import Path
import pandas as pd
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, mean_absolute_error, r2_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LinearRegression

BASE = Path(__file__).resolve().parent
DATA_PATH = BASE / "train.csv"
app = FastAPI(title="Machine Learning Lab Project", version="1.0")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

def load_data():
    if not DATA_PATH.exists():
        raise FileNotFoundError("Please download train.csv from Kaggle and place it beside main.py.")
    df = pd.read_csv(DATA_PATH)
    needed = {"Survived", "Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Embarked"}
    missing = needed - set(df.columns)
    if missing:
        raise ValueError("Dataset is missing columns: " + ", ".join(sorted(missing)))
    return df

def build_preprocessor(numeric, categorical, scale=False):
    num_steps = [("imputer", SimpleImputer(strategy="median"))]
    if scale:
        num_steps.append(("scaler", StandardScaler()))
    cat_steps = [("imputer", SimpleImputer(strategy="most_frequent")),
                 ("onehot", OneHotEncoder(handle_unknown="ignore"))]
    return ColumnTransformer([
        ("num", Pipeline(num_steps), numeric),
        ("cat", Pipeline(cat_steps), categorical)
    ])

def run_models():
    df = load_data()
    features = ["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Embarked"]
    X = df[features]
    y = df["Survived"].astype(int)
    numeric = ["Pclass", "Age", "SibSp", "Parch", "Fare"]
    categorical = ["Sex", "Embarked"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    models = {
        "Decision Tree (Gini)": DecisionTreeClassifier(criterion="gini", max_depth=4, random_state=42, class_weight="balanced"),
        "Decision Tree (Entropy)": DecisionTreeClassifier(criterion="entropy", max_depth=4, random_state=42, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42, class_weight="balanced"),
        "SVM": SVC(kernel="rbf", class_weight="balanced"),
        "Naive Bayes": GaussianNB()
    }
    results = []
    for name, model in models.items():
        scaler_needed = name == "SVM"
        prep = build_preprocessor(numeric, categorical, scale=scaler_needed)
        pipe = Pipeline([("preprocess", prep), ("model", model)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        tn, fp, fn, tp = confusion_matrix(y_test, pred, labels=[0, 1]).ravel()
        results.append({
            "model": name,
            "accuracy": round(float(accuracy_score(y_test, pred)), 3),
            "precision": round(float(precision_score(y_test, pred, zero_division=0)), 3),
            "recall": round(float(recall_score(y_test, pred, zero_division=0)), 3),
            "f1": round(float(f1_score(y_test, pred, zero_division=0)), 3),
            "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}
        })
    counts = y.value_counts().sort_index()
    return {
        "dataset_rows": int(len(df)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "class_counts": {"did_not_survive": int(counts.get(0, 0)), "survived": int(counts.get(1, 0))},
        "imbalance_note": "Compare the two class counts. Accuracy alone may hide poor performance on the smaller class, so precision, recall and F1 are also shown.",
        "results": results
    }

def run_regression():
    df = load_data()[["Age", "Fare"]].dropna()
    X = df[["Age"]]
    y = df["Fare"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("model", LinearRegression())])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    return {
        "task": "Predict Fare using Age (simple linear regression)",
        "rows_used": int(len(df)),
        "mean_absolute_error": round(float(mean_absolute_error(y_test, pred)), 3),
        "r2_score": round(float(r2_score(y_test, pred)), 3),
        "slope": round(float(pipe.named_steps["model"].coef_[0]), 3),
        "intercept": round(float(pipe.named_steps["model"].intercept_), 3),
        "note": "This is a simple teaching example; age alone is not expected to predict fare well."
    }

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/classification")
def classification():
    try:
        return run_models()
    except (FileNotFoundError, ValueError) as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/regression")
def regression():
    try:
        return run_regression()
    except (FileNotFoundError, ValueError) as e:
        raise HTTPException(status_code=400, detail=str(e))
