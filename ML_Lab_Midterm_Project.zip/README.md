# Machine Learning Lab Midterm Project

**Dataset:** Titanic - Machine Learning from Disaster (Kaggle)  
Dataset page: https://www.kaggle.com/competitions/titanic/data

## What this project covers
- Simple linear regression: predict passenger fare from age (for learning purposes)
- Classification: predict survival
- Decision tree (Gini and Entropy)
- Information gain (explained in the report; decision-tree split criteria compared)
- Random forest
- Support Vector Machine (SVM)
- Naive Bayes
- Class imbalance: class counts and class-weighted models
- Data preprocessing, evaluation, FastAPI backend, and HTML/CSS/JavaScript frontend

## Setup
1. Download `train.csv` from the Kaggle Titanic competition page. You may need a free Kaggle account and to accept the competition rules.
2. Put `train.csv` in this project folder, beside `main.py`.
3. Install Python 3.10 or newer.
4. Open a terminal in this folder and run:
   `pip install -r requirements.txt`
5. Start the backend:
   `uvicorn main:app --reload`
6. Open http://127.0.0.1:8000 in your browser. API documentation is at http://127.0.0.1:8000/docs.

## Notes
- The dataset is used for classroom practice, not real-world decisions.
- `Fare` regression is a deliberately simple example and is not intended as a useful fare-pricing model.
- The project creates a balanced training sample for the class-imbalance demonstration only if needed? No: the main classification models use the original split and report class counts.
- Results can vary slightly by scikit-learn version and dataset file.
