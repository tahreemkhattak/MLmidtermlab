# Machine Learning Lab Midterm Report

## Title
Comparison of Machine Learning Models Using the Titanic Dataset

## Dataset
The project uses the Titanic training dataset from Kaggle's *Titanic - Machine Learning from Disaster* competition. The target column is `Survived` (0 = did not survive, 1 = survived). Features used for classification are passenger class, sex, age, siblings/spouses aboard, parents/children aboard, fare and port of embarkation.

Source: https://www.kaggle.com/competitions/titanic/data

## Preprocessing
Rows are split into training and testing sets. Missing numeric values are filled using the median, and missing categorical values are filled using the most frequent value. Categorical features are converted to numeric columns using one-hot encoding. SVM also uses feature scaling. The split is stratified so both target classes are represented in train and test data.

## Models and concepts
1. **Decision Tree (Gini):** uses Gini impurity to select splits.
2. **Decision Tree (Entropy):** uses entropy to select splits.
3. **Information gain:** entropy before a split minus the weighted entropy after the split. The entropy tree chooses splits to reduce entropy.
4. **Random Forest:** combines predictions from multiple decision trees.
5. **SVM:** learns a separating boundary between survival classes.
6. **Naive Bayes:** applies Bayes' theorem with a simplifying conditional-independence assumption.
7. **Simple linear regression:** predicts `Fare` from `Age`, using a single input feature.
8. **Class imbalance:** target class counts are reported. Accuracy, precision, recall and F1 are presented because accuracy by itself may not describe performance on the smaller class.

## Evaluation
Classification models are evaluated on the held-out test set using accuracy, precision, recall, F1-score and confusion-matrix counts. Regression is evaluated using mean absolute error (MAE) and R². Run the dashboard after adding `train.csv` to obtain the numerical results; results are not written here in advance because they depend on the dataset file and software version.

## Application
FastAPI provides `/api/classification` and `/api/regression` endpoints. The HTML/CSS/JavaScript frontend calls these endpoints and displays the results in tables.

## Conclusion
This project provides a basic comparison of classification methods and a simple regression example. The best classifier should not be selected by accuracy alone; precision, recall, F1 and the confusion matrix should also be considered. The regression example is intentionally simple and is used to demonstrate the workflow rather than make strong predictions.
